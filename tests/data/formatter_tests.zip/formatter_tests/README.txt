Zip file of datasets that can be used for testing different formatter
code paths.

* LogFormatter uses local file.
* PackagesFormatter uses URI.
* MetricsExampleFormatter uses stream.
